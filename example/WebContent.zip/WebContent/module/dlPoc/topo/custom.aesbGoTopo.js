(function (undefined) {

	(function (factory) {
		"use strict";

		// amd module
		if (typeof define === "function" && define.amd) {
			define(["jquery",'./go.js'], factory);
		}
		// global
		else {
			factory();
		}

	})
		(function ($, go) {
			"use strict";
			var widget={
				custom:{}
			};

			var GoMarker = go.GraphObject.make,
				TYPE = {
					DB: 'DB',
					DEPARTMENT: 'department',
					USERS: 'users',
					MIDDLEWARE: 'middleware',
					OS:'OS'
				},
				TYPE_COLOR = {
					loadBalancing: '#f1f1f2',
					netgate: '#3CE1FF',
					platform: '#0066FF'
				};

			var example={
				//节点信息
				linkDataArray :[
					{ from: "loadBalancing1", to: "A1" },
					{ from: "loadBalancing1", to: "A2" },
					{ from: "loadBalancing1", to: "A3" },

					{ from: "A1", to: "loadBalancing2" },
					{ from: "A2", to: "loadBalancing2" },
					{ from: "A3", to: "loadBalancing2" },

					{ from: "loadBalancing2", to: "B1" },
					{ from: "loadBalancing2", to: "B2" },
					{ from: "loadBalancing2", to: "B3" },

					{ from: "B1", to: "platform1" },
					{ from: "B2", to: "platform2" },
					{ from: "B3", to: "platform3" },

					{ from: "platform3", to: "file1" },
					{ from: "platform2", to: "file1" },

					{ from: "file1", to: "C1" },
					{ from: "file2", to: "C1" },

					{ from: "file1", to: "C2" },
					{ from: "file2", to: "C2" },

					{ from: "C1", to: "C2" },
					{ from: "C2", to: "C1" },

					{ from: "platform1", to: "D1" },
					{ from: "platform2", to: "D1" },
					{ from: "platform3", to: "D1" },

					{ from: "platform1", to: "Z1" },
					{ from: "platform2", to: "Z1" },
					{ from: "platform3", to: "Z1" },

					{ from: "platform1", to: "Z2" },
					{ from: "platform2", to: "Z2" },
					{ from: "platform3", to: "Z2" },

					{ from: "platform1", to: "Z3" },
					{ from: "platform2", to: "Z3" },
					{ from: "platform3", to: "Z3" },

					{ from: "platform1", to: "Z4" },
					{ from: "platform2", to: "Z4" },
					{ from: "platform3", to: "Z4" }
				],
				linkDataMap : {
					loadBalancing1: {
						desp: 'F5负载均衡',
						type: TYPE.LOAD_BALANCING
					},
					A1: {
						desp: '172.50.2.124',
						type: TYPE.NETGATE,
						children: [{
							desp: '交易版1000',
							type: 'button'
						}, {
							desp: '查询版800'
						}]
					},
					A2: {
						desp: '172.50.2.122',
						type: TYPE.NETGATE,
						children: [{
							desp: '交易版1000'
						}, {
							desp: '查询版800'
						}]
					},
					A3: {
						desp: '172.50.2.123',
						type: TYPE.NETGATE,
						children: [{
							desp: '交易版1000'
						}, {
							desp: '查询版800'
						}]
					},
					loadBalancing2: {
						desp: 'F5负载均衡',
						type: TYPE.LOAD_BALANCING
					},
					B1: {
						desp: '172.50.5.151',
						type: TYPE.NETGATE,
						children: [{
							desp: '多企业操作'
						}]
					},
					B2: {
						desp: '172.50.5.152',
						type: TYPE.NETGATE,
						children: [{
							desp: '多企业操作'
						}]
					},
					B3: {
						desp: '172.50.5.153',
						type: TYPE.NETGATE,
						children: [{
							desp: '多企业操作'
						}]
					},
					platform1: {
						desp: '172.50.5.156',
						type: TYPE.PLATFORM,
						children: [{
							desp: '对公平台A003'
						}]
					},
					platform2: {
						desp: '172.50.5.154',
						type: TYPE.PLATFORM,
						children: [{
							desp: '对公平台A003'
						}]
					},
					platform3: {
						desp: '172.50.5.155',
						type: TYPE.PLATFORM,
						children: [{
							desp: '对公平台A003'
						}]
					},
					file1: {
						desp: '172.50.5.152',
						type: TYPE.SERVER,
						children: [{
							desp: '文件服务F001'
						}]
					},
					file2: {
						desp: '172.50.5.153',
						type: TYPE.SERVER,
						children: [{
							desp: '文件服务F002'
						}]
					},

					C1: {
						desp: '172.50.5.157',
						type: TYPE.SERVER,
						children: [{
							desp: '文件存储1111'
						}]
					},
					C2: {
						desp: '172.50.5.158',
						type: TYPE.SERVER,
						children: [{
							desp: '文件存储222'
						}]
					},
					D1: {
						desp: '194.1.2.8',
						type: TYPE.SERVER,
						children: [{
							desp: '数据库K3800'
						}]
					},


					Z1: {
						desp: '198.10.1.22\n198.10.1.13\n198.10.1.14',
						type: TYPE.SERVER,
						children: [{
							desp: '综合10010'
						}]
					},

					Z2: {
						desp: '172.30.5.120',
						type: TYPE.SERVER,
						children: [{
							desp: '签名服务S001'
						}]
					},

					Z3: {
						desp: '172.50.5.190',
						type: TYPE.SERVER,
						children: [{
							desp: 'FA服务2040'
						}]
					},

					Z4: {
						desp: '172.50.5.72',
						type: TYPE.SERVER,
						children: [{
							desp: '加速器4516'
						}]
					}
				}
			}

			var Component = function ($widget, option, attr, css, auiCtx) {
				var context = this;

				//Data Model
				context.$view = $widget;
				context.option = $.extend(true, {}, this.setting, option);
				context.attr = attr;
				context.css = css;
				context.pageContext = auiCtx;

				

				//View Model
				context.viewCache = {};

				//初始化
				context._init();
			};


			Component.prototype = Component.fn = {
				constructor: Component,
				version: 'AWOS 5.1 XQ',
				author: 'your name',

				debug: window.auiApp && window.auiApp.debug,
				example: example,

				_init: function () {
					var context=this,
						option = context.option,
						myDiagram;

					this.$view.css({
						height: option.height,
						width: option.width,
						border: '1px solid #efefef',
						overflow: 'auto'
					});

					//初始化
					this.id='ctt'+(app.global&&app.global.getUniqueId()||app.getUID());
					this.$view.empty().append('<div id= "' + this.id +'" class="diagram-ctt"></div>');

					myDiagram=this.myDiagram = GoMarker(go.Diagram,
							this.id,//填充内容div的ID
							{ // automatically scale the diagram to fit the viewport's size
								initialAutoScale: go.Diagram.Uniform,
								// start everything in the middle of the viewport
								initialContentAlignment: go.Spot.Center,
								// disable user copying of parts
								allowCopy: false,
								// position all of the nodes and route all of the links
								layout: GoMarker(go.LayeredDigraphLayout, {
									direction: 90,
									layerSpacing: 10,
									columnSpacing: 15,
									setsPortSpots: false
								})
							});

					
					// replace the default Node template in the nodeTemplateMap
					myDiagram.nodeTemplate =
						GoMarker(
							go.Node,
							"Vertical",  // the whole node panel
							{
								click:function(ev,item){
									if(context._nodeClickCallback){
										context._nodeClickCallback.call(context,ev,item,context.linkDataMap[item.data.key]);
									}
								}
							},
							GoMarker(
								go.Picture,
								//图片大小
								{ desiredSize: new go.Size(75, 75) },
								new go.Binding("source", "key", function(key){
									return context.convertKeyImage(key);
								})),
							GoMarker(
								go.TextBlock,  // the text label
								new go.Binding("text", "key", function (key){
									return context.convertKeyDesp(key);
								})),
							GoMarker(go.Panel,
								"Vertical",
								{ background: '#f1f1f2', margin: 10, width: 200 },
								GoMarker(
									go.TextBlock,  // the text label
									new go.Binding("text", "key", function(key){
										return context.convertKeyDetails(key);
									}))
							)
						);

					// replace the default Link template in the linkTemplateMap
					// myDiagram.linkTemplate =
					// 	GoMarker(go.Link,  // the whole link panel
					// 		{ curve: go.Link.Bezier, toShortLength: 2 },
					// 		GoMarker(go.Shape,  // the link shape
					// 			{ strokeWidth: 1.5 }),
					// 		GoMarker(go.Shape,  // the arrowhead
					// 			{ toArrow: "Standard", stroke: null })
					// 	);

					//连接线装饰模板
					var linkSelectionAdornmentTemplate =
						GoMarker(go.Adornment, "Link",
							GoMarker(go.Shape,
								// 声明此形状共享链接。
								{ isPanelMain: true, fill: null, stroke: "deepskyblue", strokeWidth: 0 })  // 使用选择对象的频宽
						);
					myDiagram.linkTemplate =
						GoMarker(go.Link,  // 整个链路面板
							{ selectable: true, selectionAdornmentTemplate: linkSelectionAdornmentTemplate },
							{ relinkableFrom: true, relinkableTo: true, reshapable: true },
							{
								routing: go.Link.AvoidsNodes,
								curve: go.Link.JumpOver,
								corner: 5,
								toShortLength: 4
							},
							new go.Binding("points").makeTwoWay(),
							GoMarker(go.Shape,  // 链路路径形状
								new go.Binding('stroke', 'color'),//这个是表示连续箭头的颜色，在linkDataArray中设置color属性
								{ isPanelMain: true, strokeWidth: 2 }),    //设置连线的颜色stroke: "red"
							GoMarker(go.Shape,  // 箭头
								{ toArrow: "Standard", stroke: null }),
							GoMarker(go.Panel, "Auto",
								new go.Binding("visible", "isSelected").ofObject(),
								GoMarker(go.Shape, "RoundedRectangle",  // 连杆形状   左边的圆角矩形
									{ fill: "#F8F8F8", stroke: null }),
								GoMarker(go.TextBlock,
									{
										textAlign: "center",
										font: "10pt helvetica, arial, sans-serif",
										stroke: "#919191",
										margin: 2,
										minSize: new go.Size(10, NaN),
										editable: true
									},
									new go.Binding("text").makeTwoWay())

							),
							GoMarker(go.TextBlock, new go.Binding('text', 'text'))  //这个表示linkDataArray中属性为text的值，即使连线上的文字
						);

				// the array of link data objects: the relationships between the nodes
				},

				convertKeyImage: function (key) {
					return './img/topo2/' + (this.linkDataMap[key].type || TYPE.USERS) + '.png';
				},
				convertKeyDesp: function (key) {
					return '\n' + this.linkDataMap[key].desp;
				},
				convertKeyDetails: function (key) {
					return '\n' + this.linkDataMap[key].details +'\n';
				},
				convertKeyColor: function (key) {
					return TYPE_COLOR[(this.linkDataMap[key].type || TYPE.NETGATE)];
				},


				setNodeInfo:function(list,map){
					this.linkDataMap=map;
					this.linkDataArray=list;

					// create the model and assign it to the Diagram
					this.myDiagram.model =
						GoMarker(go.GraphLinksModel,
							{ // automatically create node data objects for each "from" or "to" reference
								// (set this property before setting the linkDataArray)
								archetypeNodeData: {},
								// process all of the link relationship data
								linkDataArray: list
							});
				},
				getNodeInfo:function(){
					var model=this.myDiagram.model;


					return {
						linkDataArray: model.linkDataArray && model.linkDataArray.length ? model.linkDataArray.map(function(elem){
							return {
								from:elem.from,
								to:elem.to
							};
						}):[],
						linkDataMap: model.mg && model.mg.length? model.mg.map(function(elem){
							return {
								key:elem.key
							};
						}):[]
					};
				},
				click:function(callback){
					this._nodeClickCallback=callback;
				}
			};

			//下面的代码，如无必要，无需修改，但需要查看每个入参的意义
			widget.custom.aesbGoTopo = function ($widget, option, attr, css, auiCtx) {
				return new Component($widget, option, attr, css, auiCtx);
			};

			return widget.custom.aesbGoTopo;
		});
})();
