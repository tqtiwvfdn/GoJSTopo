define(['./custom.aesbGoTopo.js'],function(aesbGoTopo){
    return {
        load: function($el, scope, handler) {
           
            var input = {
                nodes: [ {
                    dmDefEname: "DB",
                    dmDefId: 96,
                    dmDefName: "数据库",
                    dmDtEname: "not config",
                    dmDtName: "未配置",
                    icon: "",
                    id: "96"
                }, {
                    dmDefEname: "department",
                    dmDefId: 59,
                    dmDefName: "部门",
                    dmDtEname: "not config",
                    dmDtName: "未配置",
                    icon: "",
                    id: "59"
                }, {
                    dmDefEname: "users",
                    dmDefId: 41,
                    dmDefName: "用户",
                    dmDtEname: "not config",
                    dmDtName: "未配置",
                    icon: "",
                    id: "41"
                }, {
                    dmDefEname: "middleware",
                    dmDefId: 82,
                    dmDefName: "中间件",
                    dmDtEname: "not config",
                    dmDtName: "未配置",
                    icon: "",
                    id: "82"
                }, {
                    dmDefEname: "OS",
                    dmDefId: 72,
                    dmDefName: "操作系统",
                    dmDtEname: "not config",
                    dmDtName: "未配置",
                    icon: "",
                    id: "72"
                } ],
                topologys: [ {
                    color: "yellow",
                    relDefType: 0,
                    relName: "管理",
                    sourceId: "41",
                    targetId: "72"
                }, {
                    color: "yellow",
                    relDefType: 0,
                    relName: "管理",
                    sourceId: "41",
                    targetId: "82"
                }, {
                    color: "yellow",
                    relDefType: 0,
                    relName: "管理",
                    sourceId: "41",
                    targetId: "96"
                }, {
                    color: "red",
                    relDefType: 1,
                    relName: "隶属于",
                    sourceId: "41",
                    targetId: "59"
                } ]
            };
            var linkDataMap = {};
            input.nodes.forEach(function(node) {
                node.details = node.dmDefName;
                node.desp = node.dmDtName;
                node.type = node.dmDefEname;
                linkDataMap[node.id] = node;
            });
            var linkDataArray = input.topologys.map(function(link) {
                link.from = link.sourceId;
                link.to = link.targetId;
                link.text = link.relName;
                return link;
            });

            //debugger;
            var aesbGoTopo2=aesbGoTopo($('[data-role=topo]',$el),{
                height:$el.find('.topo-full').height(),
                width:$el.find('.topo-full').width()
            });
            
            aesbGoTopo2.setNodeInfo(linkDataArray, linkDataMap);
            aesbGoTopo2.click(function(ev, model, node) {
                app.domain.exports("dataList", node);
                app.dispatch.load({
                    title: "数据详情页面",
                    moduleId: "test",
                    section: "dataList"
                });
            });
        },
        resume: function($el, scope, handler) {
           
        },
        pause: function($el, scope, handler) {
           
        },
        unload: function($el, scope, handler) {
           
        }
    }
});